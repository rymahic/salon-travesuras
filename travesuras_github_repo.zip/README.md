# Travesuras – Landing Page

**Sitio estático** para un salón de fiestas infantiles, listo para hospedarse en **GitHub Pages** o importarse visualmente en **Framer**.

## Contenido
- `index.html` – estructura principal
- `style.css` – estilos base con animaciones (fade, slide, zoom, hover, scroll‑reveal)
- `logo_travesuras_limpio.png` – logo con fondo transparente
- `.gitignore` – ignora archivos de sistema/editores
- `LICENSE` – MIT

## Uso rápido

```bash
# Clona el repositorio (o reemplaza la URL con la tuya)
git clone https://github.com/<tu-usuario>/travesuras.git
cd travesuras

# Abre el archivo en tu navegador
open index.html            # macOS
# o
start index.html           # Windows
# o
xdg-open index.html        # Linux
```

### Publicar en GitHub Pages
1. Activa *Pages* en la pestaña **Settings → Pages**.  
2. Selecciona la rama `main` y la carpeta `/root`.  
3. ¡Listo! Tu sitio estará disponible en `https://<tu-usuario>.github.io/travesuras/`.

### Importar a Framer
Sigue el tutorial **HTML to Framer**:
1. Abre `index.html` en tu navegador local.
2. Usa la extensión “HTML to Framer” para copiar cada sección y pégala en un proyecto en blanco.
3. Ajusta colores, tipografías o agrega componentes nativos de Framer Motion.

---

¡Disfruta construyendo experiencias increíbles para los peques!